package com.example.appimcsqlite;

public class Pessoa {
    private long id;
    private String nome, situacao;
    private int idade;
    private double peso, altura, imc;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if(!nome.isEmpty()){
            this.nome = nome;
        }

    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        if(!situacao.isEmpty()){
            this.situacao = situacao;
        }

    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        if(idade>=0){
            this.idade = idade;
        }

    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        if(peso >=0){
            this.peso = peso;
        }

    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        if(altura >= 0){
            this.altura = altura;
        }

    }

    public double getImc() {
        return imc;
    }

    public void setImc(double imc) {
        if(imc>=0){
            this.imc = imc;
        }

    }

    public Pessoa(){
        nome = "Nome pessoa";
        id = 0;
        peso = 0.0;
        altura = 0.0;
        situacao = "A definir";
        imc = 0.0;
    }

    public String textoLista(){
        String item = "";
        item += "ID: "+getId()+"  ";
        item += getNome();
        item += "\n";
        item += getIdade()+" anos  ";
        item += getAltura()+" m  ";
        item += getPeso() + "KG\n";
        item += "Situação: "+getSituacao();
        item += "  IMC: "+getImc();

        return item;
    }
}
