package com.example.appimcsqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PessoaSQLiteOpenHelper extends SQLiteOpenHelper {
    public static final String TABEA = " Pessoa ";
    public static final String COLUNA_ID = " id ";
    public static final String COLUNA_NOME = " nome ";
    public static final String COLUNA_SITUACAO = " situacao ";
    public static final String COLUNA_IDADE = " idade ";
    public static final String COLUNA_ALTURA = " altura ";
    public static final String COLUNA_PESO = " peso ";
    public static final String COLUNA_IMC = " imc ";

    public static final String DATABASE_NAME = "pessoas.db";
    public static final int DATABASE_VERSION = 1;

    private static final String CRIAR_BANCO = " create table "
            + TABEA + "("
            + COLUNA_ID + "integer primary key autoincrement , "
            + COLUNA_NOME + "text not null , "
            + COLUNA_PESO + "double not null , "
            + COLUNA_SITUACAO + "text not null , "
            + COLUNA_IMC + "double not null , "
            + COLUNA_IDADE + "int not null , "
            + COLUNA_ALTURA + "double not null );";



    public PessoaSQLiteOpenHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database){
        database.execSQL(CRIAR_BANCO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL(" DROP TABLE IF EXISTS "+TABEA);
        onCreate(db);
    }

}
