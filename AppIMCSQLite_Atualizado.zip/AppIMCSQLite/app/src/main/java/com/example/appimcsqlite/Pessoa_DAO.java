package com.example.appimcsqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class Pessoa_DAO {
    private SQLiteDatabase database;

    private String [] columns ={
            PessoaSQLiteOpenHelper.COLUNA_ID ,
            PessoaSQLiteOpenHelper.COLUNA_NOME ,
            PessoaSQLiteOpenHelper.COLUNA_IDADE ,
            PessoaSQLiteOpenHelper.COLUNA_ALTURA ,
            PessoaSQLiteOpenHelper.COLUNA_PESO ,
            PessoaSQLiteOpenHelper.COLUNA_IMC ,
            PessoaSQLiteOpenHelper.COLUNA_SITUACAO

    };

    private PessoaSQLiteOpenHelper sqLiteOpenHelper;

    public Pessoa_DAO(Context context){
        sqLiteOpenHelper = new PessoaSQLiteOpenHelper(context);
    }

    public void open() throws SQLException{
        database = sqLiteOpenHelper.getWritableDatabase();
    }

    public void close(){
        sqLiteOpenHelper.close();
    }


    public void inserir(String nome, int idade, double altura, double peso, double imc, String situacao){
        ContentValues values = new ContentValues();
        values.put(PessoaSQLiteOpenHelper.COLUNA_NOME, nome);
        values.put(PessoaSQLiteOpenHelper.COLUNA_IDADE, String.valueOf(idade));
        values.put(PessoaSQLiteOpenHelper.COLUNA_ALTURA, String.valueOf(altura));
        values.put(PessoaSQLiteOpenHelper.COLUNA_PESO, String.valueOf(peso));
        values.put(PessoaSQLiteOpenHelper.COLUNA_IMC, String.valueOf(imc));
        values.put(PessoaSQLiteOpenHelper.COLUNA_SITUACAO, situacao);

        long insertId = database.insert(PessoaSQLiteOpenHelper.TABEA, null, values);
    }


    public void alterar(long id,String nome, int idade, double altura, double peso, double imc, String situacao){
        ContentValues values = new ContentValues();
        values.put(PessoaSQLiteOpenHelper.COLUNA_NOME, nome);
        values.put(PessoaSQLiteOpenHelper.COLUNA_IDADE, String.valueOf(idade));
        values.put(PessoaSQLiteOpenHelper.COLUNA_ALTURA, String.valueOf(altura));
        values.put(PessoaSQLiteOpenHelper.COLUNA_PESO, String.valueOf(peso));
        values.put(PessoaSQLiteOpenHelper.COLUNA_IMC, String.valueOf(imc));
        values.put(PessoaSQLiteOpenHelper.COLUNA_SITUACAO, situacao);

        database.update(PessoaSQLiteOpenHelper.TABEA,values,PessoaSQLiteOpenHelper.COLUNA_ID + "=" + id,null);
    }

    public void apagar(long id){
        database.delete(PessoaSQLiteOpenHelper.TABEA,PessoaSQLiteOpenHelper.COLUNA_ID + " = " + id, null);
    }


    public Pessoa buscar(long id){
        Cursor cursor = database.query(PessoaSQLiteOpenHelper.TABEA,columns,PessoaSQLiteOpenHelper.COLUNA_ID +" = " + id,
                null,null,null,null);

        cursor.moveToFirst();

        Pessoa pessoa = new Pessoa();
        pessoa.setId(cursor.getLong(0));
        pessoa.setNome(cursor.getString(1));
        pessoa.setIdade(Integer.parseInt(cursor.getString(2)));
        pessoa.setAltura(cursor.getDouble(3));
        pessoa.setPeso(cursor.getDouble(4));
        pessoa.setImc(cursor.getDouble(5));
        pessoa.setSituacao(cursor.getString(6));

        return pessoa;

    }

    public List<Pessoa> getAll(){
        List<Pessoa> pessoas = new ArrayList<Pessoa>();

        Cursor cursor = database.query(PessoaSQLiteOpenHelper.TABEA, columns, null, null, null,
        null, null);

        cursor.moveToFirst();

        while (!cursor.isAfterLast()){
            Pessoa pessoa = new Pessoa();
            pessoa.setId(cursor.getLong(0));
            pessoa.setNome(cursor.getString(1));
            pessoa.setIdade(Integer.parseInt(cursor.getString(2)));
            pessoa.setAltura(cursor.getDouble(3));
            pessoa.setPeso(cursor.getDouble(4));
            pessoa.setImc(cursor.getDouble(5));
            pessoa.setSituacao(cursor.getString(6));
            pessoas.add(pessoa);
            cursor.moveToNext();
        }

        cursor.close();
        return pessoas;
    }

}
