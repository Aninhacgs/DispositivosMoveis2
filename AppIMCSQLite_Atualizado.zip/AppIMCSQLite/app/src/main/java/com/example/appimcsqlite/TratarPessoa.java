package com.example.appimcsqlite;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import androidx.appcompat.app.AppCompatActivity;

public class TratarPessoa extends AppCompatActivity {
    EditText edNome, edSituacao, edPeso, edAltura, edImc, edIdade;
    RadioButton btFeminino, btMasculino;
    Button button1, button2;
    private int acao;
    private long id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tratar_pessoa);
        edNome = (EditText)findViewById(R.id.editTextNome);
        edAltura = (EditText)findViewById(R.id.editTextAltura);
        edPeso = (EditText)findViewById(R.id.editTextPeso);
        edImc = (EditText)findViewById(R.id.editTextIMC);
        edSituacao = (EditText)findViewById(R.id.editTextSituacao);
        edIdade = (EditText)findViewById(R.id.editTextIdade);
        btFeminino = (RadioButton)findViewById(R.id.radioButtonFeminino);
        btMasculino = (RadioButton)findViewById(R.id.radioButtonMasculino);
        button1 = (Button)findViewById(R.id.buttonAlterar);
        button2 = (Button)findViewById(R.id.buttonExcluir);
        acao = getIntent().getExtras().getInt("acao");
        id = getIntent().getExtras().getLong("id");


        if(acao == -1){
            setTitle("Incluir Pessoa");
            button1.setText("Incluir");
            button2.setEnabled(false);
            button2.setVisibility(View.INVISIBLE);
            edNome.setText("Digite seu Nome");
            edSituacao.setText("A Definir");
            edImc.setText(String.format("%.1f",0.0));
            edPeso.setText(String.format("%.1f",0.0));
            edAltura.setText(String.format("%.1f",0.0));
            edIdade.setText("0");

        }

        else{
            setTitle("Alterar ou Incluir Pessoa");
            Pessoa aux = new Pessoa();
            Pessoa_DAO dao = new Pessoa_DAO(this);
            dao.open();
            aux = dao.buscar(id);
            edNome.setText(aux.getNome());
            edSituacao.setText(aux.getSituacao());
            edIdade.setText(aux.getIdade());
            edAltura.setText(String.format("%.1f",aux.getAltura()));
            edPeso.setText(String.format("%.1f",aux.getPeso()));
            edImc.setText(String.format("%.1f",aux.getImc()));
            dao.close();
        }

    }

    public void alterarInserir(View v){
        String nome, situacao;
        int idade;
        double peso, altura,imc;

        nome = edNome.getText().toString();
        situacao = edSituacao.getText().toString();
        idade = Integer.parseInt(edIdade.getText().toString());
        altura = Double.parseDouble(edAltura.getText().toString());
        peso = Double.parseDouble(edPeso.getText().toString());
        imc = Double.parseDouble(edImc.getText().toString());
        Pessoa_DAO dao = new Pessoa_DAO(this);
        dao.open();

        if(acao == -1){
            dao.inserir(nome,idade,altura,peso,imc,situacao);
        }
        else{
            dao.alterar(id,nome,idade,altura,peso,imc,situacao);
        }
        dao.close();
        finish();
    }


    public void excluir(View v){
        if(acao == 0){
            Pessoa_DAO dao = new Pessoa_DAO(this);
            dao.open();
            dao.apagar(id);
            dao.close();
        }
        finish();
    }


    public void voltar(View v){
        finish();
    }


    public void calcularImc(View v){
        double peso, altura, imc;
        int idade, sexo;
        String situacao;

        peso = Double.parseDouble(edPeso.getText().toString());
        altura = Double.parseDouble(edAltura.getText().toString());
        idade = Integer.parseInt(edIdade.getText().toString());

        if(btFeminino.isChecked()){
            sexo = 1;
        }else{
            sexo = 2;
        }

        imc = peso / Math.pow(altura,2);

        if(idade > 15){
            if(sexo == 1){
                if(imc < 19.1){
                    situacao = "Abaixo do Peso.";
                }
                else if(imc < 25.8){
                    situacao = "Peso Normal.";
                }
                else if(imc < 27.3){
                    situacao = "Pouco Acima do Peso.";
                }
                else if(imc < 32.3){
                    situacao = "Acima do Peso.";
                }
                else{
                    situacao = "Obesa.";
                }

            }else{
                if(imc < 20.7){
                    situacao = "Abaixo do Peso.";
                }
                else if(imc < 26.4){
                    situacao = "Peso Normal.";
                }
                else if(imc < 27.8){
                    situacao = "Pouco Acima do Peso.";
                }
                else if(imc < 31.1){
                    situacao = "Acima do Peso.";
                }
                else {
                    situacao = "Obeso.";
                }
            }
        }else{
            situacao = "<= 15 anos não verificar";
        }

        edSituacao.setText(situacao);
        edImc.setText(String.format("%.2f",imc));
    }
}